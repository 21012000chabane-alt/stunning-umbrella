# تطبيقي الذكي - Android Studio & APK Project

مشروع أندرويد تم إنشاؤه تلقائياً بواسطة **محول مشاريع Google AI Studio إلى APK**.

---

## 🚀 طريقة البناء والتثبيت السريع (Quick Start)

### 1. عبر GitHub Actions مجاناً وبدون تثبيت برامج (مستحسن):
1. قم بإنشاء مستودع جديد على GitHub (New Repository).
2. ارفع جميع ملفات هذا المجلد إلى المستودع.
3. افتح تبويب **Actions** في GitHub وستجد أن ملف الـ APK يتم بناؤه تلقائياً خلال دقيقة واحدة!
4. حمّل ملف `*-debug-apk` من صفحة الـ Action وثبته مباشرة على هاتفك!

### 2. عبر Android Studio محلياً:
1. افتح برنامج **Android Studio**.
2. اختر **Open** ثم حدد هذا المجلد.
3. انتظر انتهاء مزامنة Gradle (Gradle Sync).
4. اضغط على قائمة **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.
5. ستجد ملف الـ APK الجاهز في المسار:
   `app/build/outputs/apk/debug/app-debug.apk`

### 3. عبر سطر الأوامر (Terminal / CLI):
```bash
chmod +x gradlew
./gradlew assembleDebug
```

---

## 📱 إعدادات التطبيق (App Configuration)
- **اسم التطبيق**: تطبيقي الذكي
- **معرف الحزمة (Package ID)**: `com.aistudio.smartapp`
- **رابط المشروع**: `https://ais-dev-w75u6jqly2morlau3swwd5-594328699411.europe-west2.run.app`
- **إصدار التطبيق**: `1.0.0` (Code: 1)
- **تسريع العتاد (Hardware Acceleration)**: مفعل ✅
- **السحب للتحديث (Pull to refresh)**: مفعل ✅