@rem Gradle build script for Windows
gradle assembleDebug %*
